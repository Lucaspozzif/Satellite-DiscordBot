
module.exports = {
    name: '**Minigames🤣**'
}