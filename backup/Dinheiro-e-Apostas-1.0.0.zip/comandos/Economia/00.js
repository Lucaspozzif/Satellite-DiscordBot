
module.exports = {
    name: '**\nEconomia**\`\`\`'
}