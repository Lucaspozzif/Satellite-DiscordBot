
module.exports = {
    name: '\`\`\`**\nMinigames🤣**\`\`\`'
}