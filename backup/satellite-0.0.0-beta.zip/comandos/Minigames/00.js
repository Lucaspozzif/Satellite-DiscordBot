
module.exports = {
    name: '**\nMinigames🤣**\`\`\`'
}