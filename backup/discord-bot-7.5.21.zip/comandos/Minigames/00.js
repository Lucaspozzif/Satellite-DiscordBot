
module.exports = {
    name: '**\nMinigames🤣**'
}